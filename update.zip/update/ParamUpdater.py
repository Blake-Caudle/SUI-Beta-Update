from pymavlink import mavutil
import pymavlink
from datetime import datetime 
#import pymavlink
import time
import os
import sys



def getParams(paramFileName):
    paramDict = {}
    try:
        with open(paramFileName, 'r') as paramFile:
            paramList = paramFile.readlines()
            for param in paramList:
                if(param[0] != '#'):
                    singleParam = param.split(',')
                    paramName = singleParam[0]
                    paramValue = float(singleParam[1].strip())
                    paramDict[paramName] = paramValue
    except Exception as e:
        print(e)
        print('Occured while reading param file')
    return paramDict

def readParam(autopilot):
    while True:
        try:
            msg = autopilot.recv_msg()
            if(msg.get_type() == 'PARAM_VALUE'):
                print(str(msg.param_id))
                print(msg.param_value)
        except:
            pass     

def checkParamValue(autopilot, target_system, target_component, param_id, param_index):
    try:
        autopilot.mav.param_request_read_send(target_system, target_component, param_id, param_index, force_mavlink1=False)
    
        startTime = time.time()
        while((time.time() - startTime) < 5):
            try:
                msg = autopilot.recv_msg()
                if(msg.get_type() == 'PARAM_VALUE'):
                    if(msg.param_id == param_id):
                        #print(str(msg.param_id))
                        #print(msg.param_value)
                        return msg.param_value
            except:
                pass   
        print("Param " + param_id + " was never seen")
    except Exception as e:
        print(e)
    return 'ERROR'

def checkParamType(autopilot, target_system, target_component, param_id, param_index):
    try:
        autopilot.mav.param_request_read_send(target_system, target_component, param_id, param_index, force_mavlink1=False)
    
        startTime = time.time()
        while((time.time() - startTime) < 5):
            try:
                msg = autopilot.recv_msg()
                if(msg.get_type() == 'PARAM_VALUE'):
                    if(msg.param_id == param_id):
                        #print(str(msg.param_id))
                        #print(msg.param_type)
                        return msg.param_type
            except:
                pass   
        print("Param " + param_id + " was never seen")
    except Exception as e:
        print(e)
    return 'ERROR'
    
def findVehicleSysID(autopilot):
    Done = False
    try:
        # Ping to let the AP we are here
        autopilot.mav.ping_send(
                    time.time(), # Unix time
                    0, # Ping number
                    0, # Request ping of all systems
                    0 # Request ping of all components
                )
        startTime = time.time()        
        while(True):
            try:
                msg = autopilot.recv_msg()
                if(msg.get_type() == 'HEARTBEAT'):
                    if((msg.type == mavutil.mavlink.MAV_TYPE_FIXED_WING) or (msg.type == mavutil.mavlink.MAV_TYPE_QUADROTOR)):
                        return msg.get_srcSystem()
            except:
                pass
            if((time.time() - startTime) > 1):
                return 0
    except Exception as e:
        print(e)
        return 0

def establish_connection(baudrate): 
    try:
        #print('establish_connection')
        # Setup mavlink version and dialect
        os.environ["MAVLINK20"] = "0"
        mavutil.set_dialect("ardupilotmega")
        #print('dialect set')
        # Start mavlink connection
        autopilot = mavutil.mavlink_connection('/dev/ttymxc2',  baud=baudrate)
        #print('connection successful')
        
        stayAlive = True
        return autopilot
    except Exception as e:
        print(e)
        return 0

def main(paramFileName):
    #connect to pixhawk over mavlink
    #get the list of logs
    #download user selected log
    #repeat
    baudrates = [115200, 1500000]
    try:
        for baudrate in baudrates:
            print('Attempting to connect using baudrate: ' + str(baudrate))
            try:
                # Start mavlink connection
                autopilot = establish_connection(baudrate)
                if(autopilot == 0):
                    print('ERROR AUTOPILOT FAILED TO CONNECT')
                else:
                    tries = 0
                    while(tries < 3):
                        tries += 1
                        target_system = findVehicleSysID(autopilot)
                        print("target_system = %d" %target_system)
                        if(target_system != 0):
                            break
                    if(target_system != 0):
                            break    
            except Exception as e:
                print e
                if(tries == 3):
                    return        
     
        print('Connection Established')
        if(target_system == 0):
            print("ERROR, could not find vehicle sysID")
            return
        
        stayAlive = True
        target_component = 1
        param_index = -1

        try:
            paramDict = getParams(paramFileName)
        except Exception as e:
            print(e)
            print('Occured while reading from param file')
            return
        
        for param in paramDict:
            tries = 0
            retry = True
            while(retry and (tries < 5)):
                try:
                    tries += 1
                    print('Setting ' + param + ': ' + str(paramDict[param]))
                    #set param specifications
                    param_id = param
                    param_value = paramDict[param]
                    param_type = checkParamType(autopilot, target_system, target_component, param_id, param_index)
                    #set param
                    autopilot.mav.param_set_send(target_system, target_component, param_id, param_value, param_type, force_mavlink1=False)
                    #try to read param
                    pval = checkParamValue(autopilot, target_system, target_component, param_id, param_index)
                    
                    if(pval == 'ERROR'):
                        retry = True
                    else:
                        retry = False
                    
                    print(param_id + ' set successfully set to: ' + str(pval))
                except Exception as e:
                    print(e)
                    print('Occured while trying to update param')
                    print(param)
    
    except Exception as e:
        print(e)
        print('Caused an unhandled Exception')
    
    return
    
    
    

if __name__ == '__main__':
    main(sys.argv[1])